/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salarycalculator2;
import java.util.Scanner;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;


/**
 *
 * @author acer
 */
public class SalaryCalculator2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner input = new Scanner (System.in);
         //Import the scanner class, HashMap and Map to be used in this project
//Created an instance of the scanner class
               //Allocate a size for the employees to be added to the database
int n = 10;
//Create a HashMap with int as key and string as value since my int values(being Staff ID) is going to be unique.
Map<Integer,String> myMap = new HashMap<Integer,String>(n);
//Add values to the created HashMap
myMap.put(101,"Tola");
myMap.put(102,"Ifeoma");
myMap.put(103,"Tony");
myMap.put(104,"Tutu");
myMap.put(105,"Musa");
myMap.put(106,"Ehi");
myMap.put(107,"Bola");
myMap.put(108,"Eze");
myMap.put(109,"Ada");
myMap.put(110,"Bunmi");

//Perform the first task of asking the employee to enter their staff ID
System.out.print("Enter your Staff ID");
int staffID = input.nextInt();
//Make employee name in database to display after inputing Staff ID
String val = (String)myMap.get(staffID);

System.out.println("Hello " + val);
  
//Ask the user to enter the Amount due per Hour
System.out.print("Enter Amount due per Hour");
double amountDuePerHour = input.nextDouble();

//Ask the user to enter the TotalHoursWorked
System.out.print("Enter TotalHoursWorked");
double totalHoursWorked = input.nextDouble();
//After getting the values. Use input to calculate salary
       
        // TODO code application logic here
//instantiate the helper class (SalCalculator)
SalCalculatorHelper salary = new SalCalculatorHelper(amountDuePerHour,totalHoursWorked);
//print the total earnings per month
salary.salaryCalculator2();
}
    }
    
       
