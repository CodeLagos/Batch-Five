/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salarycalculator2;
import java.util.*;


/**
 *
 * @author acer
 */
public class SalCalculatorHelper {
    //After getting the values. Use input to calculate salary
    //Declare my variables
     double amountDuePerHour;
     double totalHoursWorked;
        //Create a constructor
     public SalCalculatorHelper (double amountDuePerHour,double totalHoursWorked){
         this.amountDuePerHour = amountDuePerHour;
         this.totalHoursWorked = totalHoursWorked;
     }
        
     //Calculations
         public void salaryCalculator2(){
         double Salary = amountDuePerHour * totalHoursWorked * 4;
         //Print out the outcome
         System.out.println("Your salary for the month is N" + Salary);
                    
     }
     
         
     
        
        
    
    
      }
       
    
}
