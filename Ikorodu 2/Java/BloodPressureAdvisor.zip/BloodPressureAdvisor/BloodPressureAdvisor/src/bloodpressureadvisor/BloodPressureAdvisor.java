/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bloodpressureadvisor;


import java.util.Scanner;

/**
 *
 * @author USER
 */
public class BloodPressureAdvisor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
   Scanner input = new Scanner(System.in);  
        
            String name= input.nextLine();
            
            
   do{
       
       System.out.println("USER NAME");
        
        System.out.println("Systolic pressure:");
        int systolic = input.nextInt();
        
        System.out.println("Diastolic pressure");
        int diastolic = input.nextInt();
        
        System.out.println("ADVICE");
        
       
        BloodPressure bloodPressure = new BloodPressure( name,systolic,diastolic);
        bloodPressure.BP();
        
       }while ( name != null );
    }
}
    



