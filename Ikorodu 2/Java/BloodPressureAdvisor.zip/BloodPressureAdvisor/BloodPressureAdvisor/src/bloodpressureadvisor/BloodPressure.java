/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bloodpressureadvisor;

/**
 *
 * @author USER
 */
class BloodPressure {
    //Declare variables
    String name ;
    int systolic;
    int diastolic;
    
    
    public BloodPressure(String name, int systolic, int diastolic) {
       
        //Assign Assignments
       this.name = name;
       this.systolic = systolic;
       this.diastolic = diastolic;
        }

   
       public void BP(){
            
           if ( systolic <=59 && diastolic <=49 ){
           System.out.println(name + "YOUR BP IS TOO LOW; PLEASE SEEK MEDICAL HELP");
           }
           
           if ( systolic>=60 && systolic < 120 && diastolic >=50 && diastolic <= 80 ){
            System.out.println( name + ": YOUR BP IS NORMAL ; You are fine ,continue to stay healthy");
    }
      
    else if ( systolic >=120 && systolic <= 129 && diastolic >=80 && diastolic <= 84){
      System.out.println( name + ": YOUR BP IS OPTIMAL, Take enough rest so it doesn't go bad ");   
    }
    
    else if ( systolic >=130 && systolic <=139 && diastolic >=85 && diastolic <= 89){
      System.out.println( name + ": YOU HAVE LOW HYPERTENSION, Visit your Doctor ; Add exercise to your daily routine ");
     }
    
     else if ( systolic >=140 && systolic <=159 && diastolic >=90 && diastolic <= 99){
        System.out.println( name + ": YOU HAVE MODERATE HYPERTENSION,Visit your Doctor ;Make sure you check your lifestyle");
     }
     
      else if ( systolic >=160 && systolic <=179 && diastolic >=100 && diastolic <= 109){
      System.out.println( name + ": BP IS TOO HIGH; RUSH TO YOUR DOCTOR; Don't try self medication because you definitely need help");
      }
      
      else if ( systolic >= 180 && diastolic >= 110){
      System.out.println( name +": YOUR BP IS IN AN EMERGENCY STATE!!!");
    
      }
      else{
    System.out.println(name +": please recheck your BP");       
      }
         
       
         
      
}
}
  
         
    
            
            
            

       
        
 
 

    
    