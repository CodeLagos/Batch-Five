/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* CODELAGOS PROJECT
Epe Divisional Library behind Recreation Centre , Epe
Java Aternoon Class
This program will calculate the Grading Point of A Semester

Project  by :
SHARAFADEEN ABDULMUIZ OLAYEMI   email: abdulmuizsharafadeen@gmail.com
*/
package project.cgpa;

import java.util.Scanner;
/**
 *
 * @author user pc
 */
public class ProjectCGPA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
                int ENT201 , ECE202 , ECE204 , ECE206 , ECE208 , ECE210 , ECE218 , MEE202 , MEE208 , MEE216 , total ;
                
                double GPA;
                double totalM;
                Scanner input =new Scanner(System.in);
                System.out.println("Enter the GP of ten Subjects");
                ENT201 = input.nextInt();
                ECE202 = input.nextInt();
                ECE204 = input.nextInt();
                ECE206 = input.nextInt();
                ECE208 = input.nextInt();
                ECE210 = input.nextInt();
                ECE218 = input.nextInt();
                MEE202 = input.nextInt();
                MEE208 = input.nextInt();
                MEE216 = input.nextInt();
                total = ENT201 + ECE202 + ECE204 + ECE206 + ECE208 + ECE210 + ECE218 + MEE202 + MEE208 + MEE216  ;
             //input course units  
                 System.out.println("Enter the course unit of ten Subjects");
            int    ent201 = input.nextInt();
            int    ece202 = input.nextInt();
            int    ece204 = input.nextInt();
            int    ece206 = input.nextInt();
           int     ece208 = input.nextInt();
           int     ece210 = input.nextInt();
           int     ece218 = input.nextInt();
           int     mee202 = input.nextInt();
           int     mee208 = input.nextInt();
           int     mee216 = input.nextInt();
                   
        //This is the multiplication of Grade point and the course unit       
         int  MENT201 = ENT201 * ent201;
         int MECE202 = ECE202 * ece202;
         int MECE204 = ECE204 * ece204;
         int MECE206 = ECE206 * ece206;
         int MECE208 = ECE208 * ece208;
         int MECE210 = ECE210 * ece210;
         int MECE218 = ECE218 * ece218;
         int MMEE202 = MEE202 * mee202;
         int MMEE208 = MEE208 * mee208;
         int MMEE216 = MEE216 * mee216;
         
         totalM = MENT201 + MECE202 + MECE204 + MECE206 + MECE208 + MECE210 + MECE218 +  MMEE202 +  MMEE208 +  MMEE216 ;
                 
                 
                 
                 
                 
                 
                GPA= (totalM/20.0);
               System.out.println("Total Marks Obtained = " + totalM);
                System.out.println("GPA is " + GPA);
                
            }
        }
    
    

