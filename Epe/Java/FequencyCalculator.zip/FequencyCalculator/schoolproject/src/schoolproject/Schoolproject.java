/*
CODE LAGOS

Afternoon Session

Name of Project : CalMD For Ungrouped Data With Frequency

Use of Project  : It is use to calculate the mean, variance, and standard deviation for ungrouped data with frequency 

Name : Olayiwola Ameena Idowu    E-mail: ameenaidowu@gmail.com
 */
package schoolproject;
import java.util.Scanner;
/**
 *
 * @author Ameena
 */
public class Schoolproject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

/**
 *
 * @author Ameena
 */
        // Create an instance of the Scanner class
        Scanner input = new Scanner(System.in);
       
       // declaration of variables
        double  SumFrequenies;
        double StandardDeviation;
        double ArithmeticMean;
        double variance;
        double  deviation1;
        double  deviation2;
        double  deviation3;
        double  deviation4;
        double  deviation5;
        double  deviation6;
        double  deviation7;
        double  deviation8;
        double   MFS1,   MFS2,   MFS3,   MFS4,   MFS5,   MFS6,   MFS7,   MFS8, SumMFS ;
        double    MDF1,   MDF2,   MDF3,   MDF4,   MDF5,   MDF6,   MDF7,   MDF8, SumMDF ;
         //Ask the User to enter the value of the set of scores
         System.out.println("Enter the sets of Scores: ");
         double score1 = input.nextDouble();
         double score2  = input.nextDouble();
         double score3   = input.nextDouble();
         double score4  = input.nextDouble();
         double score5   = input.nextDouble();
         double score6   = input.nextDouble();
         double score7   = input.nextDouble();
         double score8   = input.nextDouble();
        
         System.out.println("Enter the sets of Frequencies: ");
          //Ask the User to enter the value of the set of Frequencies
         double Frequency1 = input.nextDouble();
         double Frequency2  = input.nextDouble();
         double Frequency3   = input.nextDouble();
         double Frequency4 = input.nextDouble();
         double Frequency5   = input.nextDouble();
         double Frequency6   = input.nextDouble();
         double Frequency7   = input.nextDouble();
         double Frequency8  = input.nextDouble();
         
         //Compute SumFrequenies
      SumFrequenies =  Frequency1 +  Frequency2 +  Frequency3 +  Frequency4 +  Frequency5 +  Frequency6 +  Frequency7 +  Frequency8 ;
       
       MFS1 =  Frequency1 * score1;
       MFS2 =  Frequency2 * score2;
       MFS3 =  Frequency3 * score3;
       MFS4 =  Frequency4 * score4;
       MFS5 =  Frequency5 * score5;
       MFS6 =  Frequency6 * score6;
       MFS7 =  Frequency7 * score7;
       MFS8 =  Frequency8 * score8;
       
       SumMFS =  MFS1 + MFS2 + MFS3 + MFS4 + MFS5 + MFS6 + MFS7 + MFS8;
     
              //  compute  ArithmeticMean     
      ArithmeticMean =  SumMFS / SumFrequenies ;
      
         //  compute  deviations
      deviation1 = Math.pow(score1- ArithmeticMean,2);
      deviation2 = Math.pow(score2- ArithmeticMean,2);
      deviation3 = Math.pow(score3- ArithmeticMean,2);
      deviation4 = Math.pow(score4- ArithmeticMean,2);
      deviation5 = Math.pow(score5- ArithmeticMean,2);
      deviation6 = Math.pow(score6- ArithmeticMean,2);
      deviation7 = Math.pow(score7- ArithmeticMean,2);
      deviation8 = Math.pow(score8- ArithmeticMean,2);
               //  compute   MDF
      MDF1 = Frequency1 *   deviation1;
      MDF2 = Frequency2 *   deviation2;
      MDF3 = Frequency3 *   deviation3;
      MDF4 = Frequency4 *   deviation4;
      MDF5 = Frequency5 *   deviation5;
      MDF6 = Frequency6 *   deviation6;
      MDF7 = Frequency7 *   deviation7;
      MDF8 = Frequency8 *   deviation8;
      
      SumMDF =  MDF1 +  MDF2 +  MDF3 +  MDF4 +  MDF5 +  MDF6 +  MDF7 +  MDF8 ;
      
       //Print out the Result of ArithmeticMean
       System.out.println("The  Arithmetic Mean value is "  +  ArithmeticMean );
       
       
    
       //  compute variance
       variance =   SumMDF / SumFrequenies ;
        
        //Print out the Result of Variance
       System.out.println("The  Variance  value is "  +  variance  );
       
       StandardDeviation = Math.sqrt( variance);
       
            //Print out the Result of  Standard Deviation
       System.out.println("The   Standard Deviation  value is "  +   StandardDeviation  );
        
    } //End Method
    
}//End Class

    
    

