/*
 CODE LAGOS

Afternoon Session

Name of Project : CalMD For Ungrouped Data Without Frequency

Use of Project  : It is use to calculate the mean, variance, and standard deviation for ungrouped data without frequency 

Name : Mohammed Olatunji Abubakar    E-mail: olatunji.md1@gmail.com
 */
package project;
import java.util.Scanner;
/**
 *
 * @author Ameena
 */
public class Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Create an instance of the Scanner class
        Scanner input = new Scanner(System.in);
       
        // declaration of variables
        double SumOfFrequencies;
        double StandardDeviation;
        double ArithmeticMean;
        int LenghtNumber  ;
        double variance;
        double  SumDeviaion;
        double  deviation1;
        double  deviation2;
        double  deviation3;
        double  deviation4;
        double  deviation5;
        double  deviation6;
        double  deviation7;
        double  deviation8;
        
         //Ask the User to enter the value of the set of frequencies
         System.out.println("Enter the sets of Frequencies: ");
         double Frequency1 = input.nextDouble();
         double Frequency2  = input.nextDouble();
         double Frequency3   = input.nextDouble();
         double Frequency4  = input.nextDouble();
         double Frequency5   = input.nextDouble();
         double Frequency6   = input.nextDouble();
         double Frequency7   = input.nextDouble();
         double Frequency8   = input.nextDouble();
        
         
        //Ask the User to enter the value of the lenghtnumber
        System.out.println("Enter the LenghtNumber: ");
          LenghtNumber = input.nextInt();
       
     //  compute SumOfFrequencies
SumOfFrequencies = Frequency1 + Frequency2 + Frequency3 + Frequency4 + Frequency5  + Frequency6  + Frequency7  + Frequency8 ;
     
              //  compute  ArithmeticMean     
      ArithmeticMean = (SumOfFrequencies / LenghtNumber);
      
         //  compute  deviations
      deviation1 = Math.pow(Frequency1- ArithmeticMean,2);
      deviation2 = Math.pow(Frequency2- ArithmeticMean,2);
      deviation3 = Math.pow(Frequency3- ArithmeticMean,2);
      deviation4 = Math.pow(Frequency4- ArithmeticMean,2);
      deviation5 = Math.pow(Frequency5- ArithmeticMean,2);
      deviation6 = Math.pow(Frequency6- ArithmeticMean,2);
      deviation7 = Math.pow(Frequency7- ArithmeticMean,2);
      deviation8 = Math.pow(Frequency8- ArithmeticMean,2);
      
         
      
       //Print out the Result of ArithmeticMean
       System.out.println("The  Arithmetic Mean value is "  +  ArithmeticMean );
       
       //  compute  SumDeviaion
       SumDeviaion =  deviation1 + deviation2 + deviation3 + deviation4 +deviation5 + deviation6 + deviation7 + deviation8 ;
    
       //  compute variance
       variance =  SumDeviaion / LenghtNumber ;
        
        //Print out the Result of Variance
       System.out.println("The  Variance  value is "  +  variance  );
       
       StandardDeviation = Math.sqrt(variance);
       
        //Print out the Result of  StandardDeviation
       System.out.println("The StandardDeviation  value is "  +  StandardDeviation );
        
    } //End Method
    
}//End Class
