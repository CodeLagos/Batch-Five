CODELAGOS PROJECT

Epe Divisional Library behind Epe Recreational Centre, Epe
Java Morning Class

==================================================================================

This program will be able to generates 6 random number in the range of 1 to 49, and store them in an array, the user inputs his own 6 guesses, stores them into an array, then each entry is compared to what the computer has stored and for each right guess the counter is incremented by 1. If the counter is 6 then you win, if not you lose.

==================================================================================
Ajayi Olufemi 
08149773598
olufemitimilehin39@gmail.com

