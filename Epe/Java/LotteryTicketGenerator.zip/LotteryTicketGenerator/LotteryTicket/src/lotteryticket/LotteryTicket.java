/*
 * CODELAGOS PROJECT

Epe Divisional Library behind Epe Recreational Centre, Epe
Java Morning Class
 * To change this template file, choose Tools | Templates
 * Ajayi Olufemi 
08149773598
olufemitimilehin39@gmail.com
 */
package lotteryticket;

import static java.lang.System.out;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Femtop
 */
public class LotteryTicket {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
                 int[] numbers = new int[49];
                                //int[] numbers = new int[49];
        int[] winningNumbers = new int[6]; //array holding 6 random numbers
        int[] userNumber = new int[6]; //array holding the input
        Scanner theNumbers = new Scanner(System.in);
        int guesses;
        int counter = 0;
        int i;
        /*
        for(i = 0; i <  numbers.length; i++){
                numbers[i] = i + 1;
           out.println(numbers[i]);
           }
        */
        //generate 6 random numbers
        for(i = 0; i < winningNumbers.length; i++ ){
                int randomNums = new Random().nextInt(49) + 1;
                winningNumbers[i] =  randomNums;                               
        }
        out.println("Enter the 6 numbers");
        for(i = 0; i < userNumber.length; i++){
                guesses = theNumbers.nextInt();
                userNumber[i] = guesses;
                out.println(userNumber[i]);
                if(winningNumbers[i] == userNumber[i] ){
                  counter+=1;
                }
         }
        if (counter == 6) {
            out.println("you won!! COngratulations!");
        }
        else
            out.println("you lose!");
        }
    }
