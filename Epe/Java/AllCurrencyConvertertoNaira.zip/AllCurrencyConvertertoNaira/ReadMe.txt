CODE LAGOS BATCH 5 PROJECT

Epe Divisional Library behind Epe Recreational Centre, Epe
Java Morning Class
===============================================================
This program is created to convert all most used high currency 
into Nigerian Naira (NGN)

PROJECT BY
Adeniyi Joseph Temidayo (Startee) - Startee.edu@gmail.com