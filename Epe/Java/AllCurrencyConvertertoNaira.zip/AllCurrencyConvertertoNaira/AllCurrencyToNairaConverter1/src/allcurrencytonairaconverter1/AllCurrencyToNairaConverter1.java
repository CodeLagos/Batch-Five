/*CODE LAGOS BATCH 5 PROJECT

Epe Divisional Library behind Epe Recreational Centre, Epe
Java Morning Class
===============================================================
This program is created to convert all most used high currency 
into Nigerian Naira (NGN)

PROJECT BY
Adeniyi Joseph Temidayo (Startee) - Startee.edu@gmail.com
*/
package allcurrencytonairaconverter1;

import java.util.Scanner;
/**
 *
 * @author SirTee
 */
public class AllCurrencyToNairaConverter1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Create an Instance for the Scanner Class
        Scanner input = new Scanner(System.in);
        
        System.out.println("Note the type of currency while entering the type of currency");
        System.out.println("1 - $(USD) ie United State Dollars");
        System.out.println("2 - €(EUR) ie Europian Euro");
        System.out.println("3 - ¥(JPY) is Japanese Yen");
        System.out.println("4 - £(GBP) ie British Pounds");
        System.out.println("5 - CHf(CHF) ie Chinese Franc"); 
        System.out.println("6 - R(ZAR) ie South African Ran");
        
        //Ask the User to enter the type of Currency
        System.out.println("Enter the type of Currency: ");
        double Currency = input.nextDouble();
                
        //Ask the User to enter the Amount
        System.out.println("Enter the Amount: ");
        double A = input.nextDouble();
        
        //Computing the Amounts in all Currencies
        double USD = (A * 365);
        double EUR = (A * 413.26);
        double JPY = (A * 3.22);
        double GBP = (A * 455.98);
        double CHF = (A * 367.54);
        double ZAR = (A * 25.46);
        
        // Print the result
        if (Currency == 1) {
            System.out.println("Amount from USD to NGN = N"+USD);
        }
        if (Currency == 2) {
            System.out.println("Amount from EUR to NGN = N"+EUR);
        }
        if (Currency == 3) {
            System.out.println("Amount from JPY to NGN = N"+JPY);
        }
        if (Currency == 4) {
            System.out.println("Amount from GBP to NGN = N"+GBP);
        }
        if (Currency == 5) {
            System.out.println("Amount from CHF to NGN = N"+CHF);
        }
        if (Currency == 6) {
            System.out.println("Amount from ZAR to NGN = N"+ZAR);
        }
        else if (Currency > 6) {
            System.out.println("Currency not found");
        }
    }// End of Class
   
}// End of Method 
