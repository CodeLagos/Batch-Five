/*
 * Pseudocode algorithm that uses counter-controlled repetition to solve the 
class-average problem for 10 input value
 */
package classaveragesolution;

//Class-average program with couter-controlled repetition.
import javax.swing.JOptionPane;

/**
 *
 * @author Tim
 */
public class ClassAverageSolution {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //sum of grades input by usser
        int total;
        
        // number of grde to be entered next
        int gradeCounter;
        
        int grade; //grade value
        
        int average; //average of grades
        
        String gradeString; // grade typed by User
        
        //initialization phase
        total = 0; //initializze total
        gradeCounter = 1; //initialize loop counter
        
        //processing phase
        while (gradeCounter <=10) { //loop 10 times
            
            //prompt for input and read grade from User
            gradeString = JOptionPane.showInputDialog(
            "Enter Integer grade: "); 
            
            //Convert gradeString to int
            grade = Integer.parseInt (gradeString);
            
            total = total + grade; // add grade total
            gradeCounter = gradeCounter + 1; //increment counter
                 
        }
        
        //termination phase
        average = total / 10; //integer division
        
        //dispaly average of Exam grades
        JOptionPane.showMessageDialog(null, "Class average is " + average, "Claas Average", JOptionPane.INFORMATION_MESSAGE);
        
        System.exit(0); //terminate the program
    }
    
}
