CODELAGOS PROJECT

Epe Divisional Library behind Epe Recreational Centre, Epe
Java Morning Class

==================================================================================

This program will be able to computer Student average of a given exam scores and display comments

==================================================================================
Obi Oluwatobi 
08162718784
oluwatobiobi123@gmail.com