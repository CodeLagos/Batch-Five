/*
CODELAGOS BATCH 5 PROJECT


 Epe Divisional Library behind Epe Recreational Centre, Epe
Java morning class

      This program will be able to carry out some basic arithmetic operation which includes product, sum, subtraction and division.

  PROJECT BY:
1. Lamina Boluwatife Rohimat - boluwatifelamina@gmail.com
*/


package project;

/**
 *
 * @author bolu
 */
import java.util.Scanner;
public class Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double num1, num2;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter first number: ");
        num1 = scanner.nextDouble();
        System.out.print("Enter second number: ");
        num2 = scanner.nextDouble();
        
        System.out.print("Enter an operator (+, -, *, /): ");
        char operator = scanner.next().charAt(0);
        scanner.close();
        double output = 0;
        
        switch(operator)
        {
            case '+':
                output = num1 + num2;
                break;
                
            case '-':
                output = num1 - num2;
                break;
                
            case '*':
                output = num1 * num2;
                break;
                
            case '/':
                output = num1 / num2;
                break;
                
                
            default:
                System.out.print("You have entered wrongoperator");
        }
        
        System.out.println(num1+" "+operator+" "+num2+": "+ output);
    }
}
        
        
        
        
        
        
        
        
        
        // TODO code application logic here
    
    

