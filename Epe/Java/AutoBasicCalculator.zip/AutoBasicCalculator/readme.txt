CODELAGOS BATCH 5 PROJECT


 Epe Divisional Library behind Epe Recreational Centre, Epe
Java morning class

      This program will be able to carry out some basic arithmetic operation which includes product, sum, subtraction and division.

  PROJECT BY:
1. Lamina Boluwatife Rohimat - boluwatifelamina@gmail.com