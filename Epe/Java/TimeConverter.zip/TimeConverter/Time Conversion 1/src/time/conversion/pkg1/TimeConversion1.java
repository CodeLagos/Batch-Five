/*
CODELAGOS BATCH 5 PROJECT


 Epe Divisional Library behind Epe Recreational Centre, Epe
Java morning class

      This program will be able to tell present time and date.

  PROJECT BY:
1. Simeon Gift- giftsimeon54@gmail.com
 */
package time.conversion.pkg1;
import java.text.DateFormat;
import java.text. ParseException;
import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 *
 * @author bolu
 */
public class TimeConversion1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
        Calendar currentdate = Calendar.getInstance();
        String strdate = null;
        DateFormat formatter = new SimpleDateFormat("dd-mm-yyyy HH:mm:ss");
        strdate = formatter.format ( currentdate.getTime());
        TimeZone obj = TimeZone.getTimeZone("CST");
        
        formatter.setTimeZone(obj);
        //System.out.println(strdate);
        //System.out.println(formatter.parse(strdate));
        Date theResult = formatter.parse(strdate);
        
        System.out.println("The current time in Nigeria is :: " +currentdate.getTime());
        System.out.println("The date and time is :: "+ obj.getDisplayName() + "is ::" + theResult);
    } catch (ParseException e) { 
       e.printStackTrace();
    }
    
}
}