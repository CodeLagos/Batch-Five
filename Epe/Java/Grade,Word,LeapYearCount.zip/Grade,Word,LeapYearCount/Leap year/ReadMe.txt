CODE LAGOS BATCH 5

Epe Divisional library behind Epe Recreation centre, Epe.
Java Morning class
==========================================================
This program check if a particular year is a leap year or not.

PROJECT BY:
Olalekan Abass Adebayo - baythegen@yahoo.com