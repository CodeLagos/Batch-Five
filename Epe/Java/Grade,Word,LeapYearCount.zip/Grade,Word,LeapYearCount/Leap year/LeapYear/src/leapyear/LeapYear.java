/*This program check if a particular year is a leap year or not.
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leapyear;
//import scanner class
import java.util.Scanner;
/**
 *
 * @author Olalekan Abass Adebayo
 * baythegen@yahoo.com
 */
public class LeapYear {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int year;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any year:");
        year = scan.nextInt();
        scan.close();
        boolean leap = false;
        
        if (year % 4 == 0)
        {
            if (year % 100 == 0)
            {
                //year is divisible by 400, hence the year is a leap year
                if (year % 400 == 0)
                    leap = true;
                else
                    leap = false;
            }
            else
                leap = true;
        }
        else
            leap = false;
        if(leap)
            System.out.println(year + " is a leap year.");
        else
            System.out.println(year + " is not a leap year.");
            }
        }
    

