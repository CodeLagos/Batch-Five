/*This program calculates the grade of a student based on the marks entered by user in each subject. 
Program print the grade based on this logic
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gradecalculator;
//import Scanner class
import java.util.Scanner;
/**
 *
 * @author Olalekan Abass Adebayo
 * baythegen@yahoo.com
 */
public class Gradecalculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //This program assumes that the student has 8 courses,
        int marks[] = new int[8];
        int i;
        float total = 0, avg;
        Scanner scanner = new Scanner(System.in);
        
        for (i=0; i<8; i++){
            System.out.print("Enter Marks of Subjects"+(i+1)+":");
            marks[i] = scanner.nextInt();
            total = total + marks[i];
        }
        scanner.close();
    //calculate average here
    avg = total/8;
    System.out.print("The student Grade is: ");
    if(avg>=70)
    {
        System.out.println("A");
    }
    else if(avg>=60 && avg <70)
    {
        System.out.println("B");
    }
    else if(avg>=50 && avg <60)
    {
        System.out.println("C");
    }
    else if(avg>45 && avg<50)
    {
        System.out.println("D");
    }
    else
    {
        System.out.println("F");
    }
  }
}
    